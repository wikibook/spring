package com.example.demo.chapter03.aop;

import java.text.SimpleDateFormat;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class SampleAspect {
	//@Before("execution(* com.example.demo.chapter03.used.*Greet.*(..))")
	public void beforeAdvice(JoinPoint joinPoint) {
		// 시작 표시
		System.out.println("===== Before Advice =====");
		// 날짜를 표시
		System.out.println(new SimpleDateFormat("yyyy/MM/dd").format(new java.util.Date()));
		// 메소드명 표시
		System.out.println(String.format("메소드명:%s", joinPoint.getSignature().getName()));
	}

	//@After("execution(* com.example.demo.chapter03.used.*Greet.*(..))")
	public void afterAdvice(JoinPoint joinPoint) {
		// 시작 표시
		System.out.println("===== After Advice =====");
		// 날짜를 표시
		System.out.println(new SimpleDateFormat("yyyy/MM/dd").format(new java.util.Date()));
		// 메소드명 표시
		System.out.println(String.format("메소드명:%s", joinPoint.getSignature().getName()));
	}

	@Around("execution(* com.example.demo.chapter03.used.*Greet.*(..))")
	public Object aroundAdvice(ProceedingJoinPoint joinPoint) throws Throwable {
		// 시작 표시
		System.out.println("===== Around Advice =====");
		System.out.println("▼▼▼ 처리 전  ▼▼▼");
		// 지정한 클래스의 지정한 메스드 실행
		Object result = joinPoint.proceed();
		System.out.println("▲▲▲ 처리 후 ▲▲▲");
		// 반환값을 돌려주어야 할 경우에는 Object형으로 반환
		return result;
	}
}
