package chapter03.used;

/**
* Calculator구현 클래스<br>
* 가산 처리
*/
public class AddCalc implements Calculator {
	@Override
	public Integer calc(Integer x, Integer y) {
		return x + y;
	}
}