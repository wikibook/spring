package com.example.demo.chapter03.used;

/**
* 인사 인터페이스
*/
public interface Greet {
	/**
	* 인사 하기
	*/
	void greeting();
}